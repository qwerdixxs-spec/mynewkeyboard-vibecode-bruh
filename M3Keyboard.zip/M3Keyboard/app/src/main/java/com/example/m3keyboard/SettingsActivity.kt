package com.example.m3keyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.DynamicColors

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun lp() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) }
        fun btn(t: String, f: () -> Unit) = MaterialButton(this).apply {
            text = t
            setOnClickListener { f() }
        }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(64), dp(24), dp(24))
        }
        col.addView(TextView(this).apply { text = "M3 Клавиатура"; textSize = 32f })
        col.addView(btn("1. Включить клавиатуру") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, lp())
        col.addView(btn("2. Выбрать клавиатуру") {
            getSystemService(InputMethodManager::class.java).showInputMethodPicker()
        }, lp())
        col.addView(EditText(this).apply { hint = "Попробуйте напечатать здесь" }, lp())
        setContentView(col)
    }
}
