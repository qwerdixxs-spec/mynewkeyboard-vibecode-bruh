package com.example.m3keyboard

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import com.google.android.material.R as M3

class KeyboardService : InputMethodService() {

    private enum class Kind { CH, SHIFT, DEL, SYM, LANG, SPACE, ENTER, GAP }
    private class Key(val label: String, val w: Float = 1f, val kind: Kind = Kind.CH)

    private val ru = listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
    private val en = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val sy = listOf("1234567890", "@#₽_&-+()/", "*\"':;!?")
    private val alt = mapOf("е" to "ё", "ь" to "ъ") // долгое нажатие

    private var lang = 0   // 0 = RU, 1 = EN
    private var sym = false
    private var shift = 0  // 0 выкл, 1 одна буква, 2 caps lock
    private lateinit var ctx: Context
    private lateinit var root: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val repeater = object : Runnable {
        override fun run() { del(); h.postDelayed(this, 45) }
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        // Material 3 + динамические цвета (Material You) на Android 12+
        ctx = DynamicColors.wrapContextIfAvailable(ContextThemeWrapper(this, R.style.Theme_M3Keyboard))
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(c(M3.attr.colorSurfaceContainer))
            setPadding(dp(4), dp(6), dp(4), dp(10))
        }
        render()
        return root
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setInputView(onCreateInputView()) // перекрасить при смене светлой/тёмной темы
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = (info?.inputType ?: 0) and EditorInfo.TYPE_MASK_CLASS
        sym = cls == EditorInfo.TYPE_CLASS_NUMBER || cls == EditorInfo.TYPE_CLASS_PHONE
        if (shift == 1) shift = 0
        afterEdit()
        render()
    }

    // ---------- раскладка ----------

    private fun rows(): List<List<Key>> {
        val l = if (sym) sy else if (lang == 0) ru else en
        val n = l[0].length.toFloat()
        fun chars(s: String) = s.map { Key(it.toString()) }
        val p2 = (n - l[1].length) / 2
        val p3 = (n - l[2].length) / 2
        return listOf(
            chars(l[0]),
            listOf(Key("", p2, Kind.GAP)) + chars(l[1]) + Key("", p2, Kind.GAP),
            listOf(Key("", p3, if (sym) Kind.GAP else Kind.SHIFT)) + chars(l[2]) + Key("", p3, Kind.DEL),
            listOf(
                Key(if (!sym) "?123" else if (lang == 0) "АБВ" else "ABC", 1.4f, Kind.SYM),
                Key("", 1f, Kind.LANG),
                Key(","),
                Key(if (lang == 0) "Русский" else "English", 4.2f, Kind.SPACE),
                Key("."),
                Key("", 1.5f, Kind.ENTER)
            )
        )
    }

    private fun render() {
        if (!::root.isInitialized) return
        root.removeAllViews()
        for (row in rows()) {
            val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { r.addView(keyView(it)) }
            root.addView(r, LinearLayout.LayoutParams(-1, dp(56)))
        }
    }

    private fun keyView(k: Key): View {
        val lp = LinearLayout.LayoutParams(0, -1, k.w)
        if (k.kind == Kind.GAP) return View(ctx).apply { layoutParams = lp }
        lp.setMargins(dp(3), dp(3), dp(3), dp(3))

        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val face = c(if (night) M3.attr.colorSurfaceContainerHighest else M3.attr.colorSurfaceContainerLowest)
        val (bg, fg) = when (k.kind) {
            Kind.ENTER -> c(M3.attr.colorPrimary) to c(M3.attr.colorOnPrimary)
            Kind.SHIFT -> when (shift) {
                0 -> c(M3.attr.colorSecondaryContainer) to c(M3.attr.colorOnSecondaryContainer)
                1 -> c(M3.attr.colorPrimaryContainer) to c(M3.attr.colorOnPrimaryContainer)
                else -> c(M3.attr.colorPrimary) to c(M3.attr.colorOnPrimary)
            }
            Kind.DEL, Kind.SYM, Kind.LANG -> c(M3.attr.colorSecondaryContainer) to c(M3.attr.colorOnSecondaryContainer)
            Kind.SPACE -> face to c(M3.attr.colorOnSurfaceVariant)
            else -> face to c(M3.attr.colorOnSurface)
        }

        val icon = when (k.kind) {
            Kind.SHIFT -> R.drawable.ic_shift
            Kind.DEL -> R.drawable.ic_backspace
            Kind.ENTER -> R.drawable.ic_enter
            Kind.LANG -> R.drawable.ic_globe
            else -> 0
        }
        val v: View = if (icon != 0) ImageView(ctx).apply {
            setImageResource(icon)
            imageTintList = ColorStateList.valueOf(fg)
            scaleType = ImageView.ScaleType.CENTER
        } else TextView(ctx).apply {
            text = if (k.kind == Kind.CH && shift > 0 && !sym) k.label.uppercase() else k.label
            setTextColor(fg)
            gravity = Gravity.CENTER
            textSize = when (k.kind) { Kind.CH -> 22f; Kind.SPACE -> 14f; else -> 16f }
        }

        val r = dp(if (k.kind == Kind.SPACE || k.kind == Kind.ENTER) 25 else 14).toFloat()
        fun shape(col: Int) = GradientDrawable().apply { cornerRadius = r; setColor(col) }
        v.layoutParams = lp
        v.background = RippleDrawable(
            ColorStateList.valueOf(ColorUtils.setAlphaComponent(fg, 60)), shape(bg), shape(Color.WHITE)
        )

        when (k.kind) {
            Kind.DEL -> v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { v.isPressed = true; buzz(v); h.postDelayed(repeater, 350); del() }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; h.removeCallbacks(repeater) }
                }
                true
            }
            else -> {
                v.setOnClickListener { buzz(v); press(k) }
                if (k.kind == Kind.CH && lang == 0 && !sym) alt[k.label]?.let { a ->
                    v.setOnLongClickListener { buzz(v); type(a); true }
                }
                if (k.kind == Kind.LANG) v.setOnLongClickListener {
                    getSystemService(InputMethodManager::class.java).showInputMethodPicker(); true
                }
            }
        }
        return v
    }

    // ---------- действия ----------

    private fun press(k: Key) {
        when (k.kind) {
            Kind.CH -> type(k.label)
            Kind.SPACE -> type(" ")
            Kind.SHIFT -> { shift = if (shift == 0) 1 else if (shift == 1) 2 else 0; render() }
            Kind.SYM -> { sym = !sym; render() }
            Kind.LANG -> { lang = 1 - lang; render() }
            Kind.ENTER -> enter()
            else -> {}
        }
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(if (shift > 0) s.uppercase() else s, 1)
        afterEdit()
    }

    private fun del() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        afterEdit()
    }

    private fun enter() {
        val o = currentInputEditorInfo?.imeOptions ?: 0
        val a = o and EditorInfo.IME_MASK_ACTION
        if ((o and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED
        ) currentInputConnection?.performEditorAction(a)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    // сброс одноразового Shift + автозаглавная буква в начале предложения
    private fun afterEdit() {
        val was = shift
        if (shift == 1) shift = 0
        val ei = currentInputEditorInfo
        if (shift == 0 && ei != null && ei.inputType != 0 &&
            (currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0) != 0
        ) shift = 1
        if (shift != was) render()
    }

    private fun buzz(v: View) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }
    private fun c(attr: Int) = MaterialColors.getColor(ctx, attr, Color.MAGENTA)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
